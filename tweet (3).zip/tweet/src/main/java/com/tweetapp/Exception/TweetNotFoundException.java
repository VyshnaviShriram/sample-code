package com.tweetapp.Exception;

public class TweetNotFoundException extends RuntimeException{

}
