package com.tweetapp.Exception;

public class UserNotFoundException extends RuntimeException {
}
