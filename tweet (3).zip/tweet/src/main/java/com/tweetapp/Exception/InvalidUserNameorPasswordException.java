package com.tweetapp.Exception;

public class InvalidUserNameorPasswordException extends RuntimeException {
}
