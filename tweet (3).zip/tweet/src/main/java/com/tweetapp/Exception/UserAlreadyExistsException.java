package com.tweetapp.Exception;

public class UserAlreadyExistsException extends Exception {
}
